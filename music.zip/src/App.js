import { Header } from "./Components/Header";

function App() {
  return (
    <div style={{ backgroundColor: "#0dcaf0" }} className="App">
      <Header />
    </div>
  );
}

export default App;
